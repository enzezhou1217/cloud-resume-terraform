import json
import boto3
import requests
import lambdalogging

LOG = lambdalogging.getLogger(__name__)
JSON_HEADER = {'Content-Type': 'application/json'}

def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))
    message = event['Records'][0]['Sns']['Message']
    client = boto3.client('ssm')
    webhook_url = client.get_parameter(Name='slack-webhook', WithDecryption=True)
    data = {'text': message}
    response = requests.post(webhook_url, data=json.dumps(data), headers=JSON_HEADER)
    LOG.info('Sent message: %s\nUrl: %s\nResponse: %s', message, webhook_url, response)
    return response.status_code



